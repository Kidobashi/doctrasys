@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="alert alert-success" role="alert">
            {{ __('Your email address has been verified.') }}
        </div>
    </div>
@endsection
