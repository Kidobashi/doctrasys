<footer class="bg-light text-dark text-center text-lg-start">
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        Copyright © <script>
        document.write(new Date().getFullYear())
        </script>
        <a class="text-dark" href="{{ route('index') }}">cmu.doctrasys.com</a>.All Rights Reserved
    </div>
    <!-- Copyright -->
  </footer>
