<h5 class="text-center">Top 3 Document Types</h5>
    <div class="bg-white p-2">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6 text-center">
                    <h6>Type</h6>
                </div>
                <div class="col-md-6 text-center">
                    <h6>Total</h6>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $miscdocumentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 text-center mb-0">
                <p style="font-size: 14px;"><?php echo e($types->docType); ?></p>
            </div>
            <div class="col-md-6 text-center">
                <p style="font-size: 14px; mb-0"><?php echo e($types->total); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <nav class="mt-3">
        <ul class="pagination justify-content-center mb-0">
            
        </ul>
    </nav>
<?php /**PATH C:\Users\Balleza\Desktop\CMU-DOCTRASYS\cmudts\doctrasys\resources\views/admin/misc/most-types.blade.php ENDPATH**/ ?>