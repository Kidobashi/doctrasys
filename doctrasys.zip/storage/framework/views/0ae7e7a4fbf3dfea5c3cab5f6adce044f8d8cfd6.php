<!-- Edit Modal -->
<div class="modal fade editModal" id="editModal<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="edit-form" method="POST" action="<?php echo e(route('admin.update-user', $user->id)); ?>" autocomplete="off">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="form-group mb-2">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                    </div>
                    <div class="form-group mb-2">
                        <label for="assignedOffice">Assign Office</label>
                        <select class="form-control" id="assignedOffice" name="assignedOffice" required>
                            <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($office->id); ?>" <?php if($user->assignedOffice == $office->id): ?> selected <?php endif; ?>><?php echo e($office->officeName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group mb-2">
                        <label for="roles">Roles</label>
                        <select class="form-control" id="roles" name="roles" required>
                          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php if($user->roles->implode('id', ', ') == $role->id): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <hr>
                      <div class="form-group">
                        <label for="password_confirmation">Administrator Password</label>
                        <input type="password" id="password2" name="check_password" autocomplete="off" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button class="btn btn-primary"  id="saveBtn">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- End Edit Modal -->
<?php /**PATH H:\FROM E\cmudts\doctrasys\resources\views/admin/modals/edit-user-modal.blade.php ENDPATH**/ ?>