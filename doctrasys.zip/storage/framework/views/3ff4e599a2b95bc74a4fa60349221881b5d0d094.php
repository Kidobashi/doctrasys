<div class="modal fade" id="enableUserModal<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="enableUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="enableUserModalLabel">Enable <em><?php echo e($user->name); ?></em></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body p-4">
                <form method="POST" action="/enable-user/<?php echo e($user->id); ?>">
                    <?php echo csrf_field(); ?>
                <div class="form-group text-wrap">
                    Confirm action by entering <em><strong>Adminisatrator</strong></em> password
                </div>
                <input type="password" id="password2" name="check_password" autocomplete="off" required>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-success">Enable</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\FROM E\cmudts\doctrasys\resources\views/admin/modals/enable-user-modal.blade.php ENDPATH**/ ?>