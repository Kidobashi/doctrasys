<!-- Edit Modal -->
<div class="modal fade" id="editReportModal<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Type of Report</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Form to edit lacking document -->
                <form action="<?php echo e(route('admin.updateReport', $row->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <input type="text" class="form-control" id="name" name="reason" value="<?php echo e($row->reason); ?>" required>
                    </div>
                    <!-- Add other fields as needed -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Balleza\Desktop\CMU-DOCTRASYS\cmudts\doctrasys\resources\views/admin/modals/edit-type-report-modal.blade.php ENDPATH**/ ?>