
<?php /**PATH H:\FROM E\cmudts\doctrasys\resources\views/partials/qrcode.blade.php ENDPATH**/ ?>