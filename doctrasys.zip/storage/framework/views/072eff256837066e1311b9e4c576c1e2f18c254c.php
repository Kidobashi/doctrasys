

<?php $__env->startSection('content'); ?>
<style>
html, body {
    height: 100%;
    width: 100%;
    /* background-image: url('/images/bg-sign-in.png'); */
    background-size: cover;
    background-repeat: no-repeat;
    overflow:hidden;
}
input{
    display: block;
    text-align: center;
}

input[type=text], input[type=email], input[type=password], select, option{
    border-radius: 20px;
    margin: auto;
    font-size: 18px;
}
.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.bg-img{
    opacity: .4;
    position: absolute;
    z-index: 1;
    left: 0;
    top: 0;
}

.container {
    position: relative;
    z-index: 2;
}

@media only screen and (max-width: 600px) {
    input[type=text], input[type=email], input[type=password], select, option{
    border-radius: 20px;
    margin: auto;
    font-size: 12px;
}
}
</style>
<section>
    <div class="container vh-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col-12 col-md-8 col-lg-6 col-xl-5">
            <div class="card" style="border-radius: 1rem;
                    -moz-box-shadow: 0px 3px 8px rgb(100,100,100);
                    -webkit-box-shadow: 0px 3px 8px rgb(100,100,100);
                    box-shadow: 0px 3px 8px rgb(100,100,100);">
              <div class="card-body px-5 text-center">
                <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <h3 class="mb-2">Create an Account</h3>
                <p>Fill-in the fields to register</p>

                <div class="form-outline mb-4">
                    <input type="text" name="name" class="form-control" placeholder="Name" required/>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-outline mb-4">
                  <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email" required />
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-outline mb-4">
                    <select class="form-control text-center" style="border-radius: 22px;" id="assignedOffice" name="assignedOffice" required>
                        <option value="" selected disabled>Select Assigned Office
                            <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option style="font-size:1.2rem;" value="<?php echo e($row->id); ?>"><?php echo e($row->officeName); ?></option>
                        </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['assignedOffice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-outline mb-4">
                    <input type="password" name="password" class="form-control" placeholder="Password" required/>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-outline mb-4">
                    <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password" required/>
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-check d-flex justify-content-center mb-4">
                    <input type="checkbox" class="form-check-input" id="terms-checkbox" name="terms">
                    <label class="form-check-label" for="terms-checkbox">&nbsp;&nbsp; I agree to the terms and conditions</label>
                    <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button class="btn btn-success btn-lg btn-block w-30 mb-2 px-5 fs-6" style="border-radius: 18px;" type="submit">Register</button>
                <div class="form-outline mb-2">
                    <?php if(Route::has('password.request')): ?>
                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot Your Password?')); ?>

                    </a>
                     <?php endif; ?>
                </div>

                <hr class="mt-2">
                <p class="mb-0">Already have an account? <a href="/login" style="border-radius: 18px;" role="button">Login here</a></p>

                
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    <div class="bg-img">
        <img src="/images/bg-sign-in.png" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\FROM E\cmudts\doctrasys\resources\views/auth/register.blade.php ENDPATH**/ ?>