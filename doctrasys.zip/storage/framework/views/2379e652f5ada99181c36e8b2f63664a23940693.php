<?php $__env->startSection('content'); ?>
<style>
    .pointer {cursor: pointer;}
    html, body {
        background-color:  #A0D6B4;
    }
    th, td {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
</style>
<div>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div class="p-2">
                            <h3 class="mb-0"><?php echo e(__('Users')); ?></h3>
                        </div>
                        <div class="p-2">
                            <button href="#" class="btn float-end btn-sm mb-0 text-white text-center" type="button" data-toggle="modal" data-target="#exampleModal" style="background:  #2AAA8A;">+&nbsp; Add User</button>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-1" style="width: 100%; overflow-x: auto;">
                        <table class="table mb-0 p-3">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        No
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Name
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Email
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Office
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                       Role
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Status
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Creation Date
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <?php echo e($loop->iteration); ?>

                                    </td>
                                    <td class=" text-center">
                                        <?php echo e($user->name); ?>

                                    </td>
                                    <td class=" text-center">
                                        <?php echo e($user->email); ?>

                                    </td>
                                    <td class=" text-center">
                                        <?php echo e($user->office->officeName); ?>

                                    </td>
                                    <td class=" text-center">
                                        <?php echo e($user->roles->implode('name', ', ')); ?>

                                    </td>
                                     <td class="text-center">
                                        <?php if($user->status == 1): ?>
                                            <span class="badge pill-rounded bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge pill-rounded bg-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php echo e(\Carbon\Carbon::parse($user->created_at)->format('Y-m-d')); ?>

                                    </td>

                                    <td class="text-center d-flex">
                                        <div class="pointer mx-3">
                                            <button class="btn p-0" data-toggle="modal" data-target="#editModal<?php echo e($user->id); ?>">
                                                <i title="Edit" type="button" class="p-2 fas fa-user-edit text-white bg-warning rounded"></i>
                                            </button>
                                        </div>
                                            <!-- Edit Modal -->
                                            <?php echo $__env->make('admin.modals.edit-user-modal', ['user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php if($user->status == 1): ?>
                                        <div class="pointer mx-3">
                                            <button class="btn p-0" type="submit" data-toggle="modal" data-target="#disableUserModal<?php echo e($user->id); ?>">
                                                <i title="Disable" class="p-2 fas fa-ban text-white bg-danger rounded"></i>
                                            </button>
                                            <?php echo $__env->make('admin.modals.disable-user-modal', ['user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                        <?php else: ?>
                                        <div class="pointer mx-3">
                                                <button class="btn p-0" type="submit" data-toggle="modal" data-target="#enableUserModal<?php echo e($user->id); ?>">
                                                    <i title="Enable" class="p-2 fas fa-thumbs-up text-white bg-success rounded"></i>
                                                </button>
                                            <?php echo $__env->make('admin.modals.enable-user-modal', ['user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                        <?php endif; ?>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form method="POST" action="<?php echo e(route('admin.addUser')); ?>">
          <?php echo csrf_field(); ?>
          <div class="modal-body">
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control text-capitalize" id="name" name="name" required>
            </div>
            <div class="form-group">
              <label for="email">Email address</label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="password">Re-enter Password</label>
                <input type="password" class="form-control" id="password" name="password_confirmation" required>
            </div>
            <div class="form-group">
                <label for="offices">Assign Office</label>
                <select class="form-control" id="offices" name="assignedOffice">
                  <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->officeName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
            <div class="form-group">
              <label for="roles">Roles</label>
              <select class="form-control" id="roles" name="roles[]">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <hr>
            <div class="form-group px-5">
                <label for="password_confirmation">Administrator Password</label>
                <input type="password" id="password2" name="check_password" autocomplete="off" required>
            </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn text-white" style="background:  #2AAA8A;">Add User</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<!-- Disable User Modal -->
<div class="modal fade" id="disableUserModal<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="disableUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="disableUserModalLabel">Disable User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="disableUserForm" action="/disable-user/<?php echo e($user->id); ?>">
                    <?php echo csrf_field(); ?>
                Are you sure you want to disable this user? Enter administrator password.                <div class="form-group d-flex">
                    <input type="password" id="password2" name="check_password" autocomplete="off" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                
                    <button type="submit" class="btn btn-danger">Disable</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Enable User Modal -->
<div class="modal fade" id="enableUserModal<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="enableUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="enableUserModalLabel">Enable User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to enable this user? Enter the Adminisatrator password
                <div class="form-group">
                    <input type="password" id="password2" name="check_password" autocomplete="off" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <form method="POST" action="/enable-user/<?php echo e($user->id); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success">Enable</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Balleza\Desktop\CMU-DOCTRASYS\cmudts\doctrasys\resources\views/admin/user-management.blade.php ENDPATH**/ ?>