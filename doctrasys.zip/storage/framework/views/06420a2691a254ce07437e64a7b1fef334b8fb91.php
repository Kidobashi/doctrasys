<?php $__env->startSection('content'); ?>
<style>
.active, .btn:hover {
  background-color: #666;
  color: white;
}

#nav {
    display: flex;
}
</style>
<div class="col-md-12">
    <h2 class="m-4">My Documents</h2>
    <a href="<?php echo e(url('documents')); ?>"><button onclick="showThree()" class="btn border d-flex justify-content-center border border-dark">Return</button></a>&nbsp;&nbsp;
</div>

<?php if(isset($data) && count($data) != 0): ?>
<div id="searchDate" class="search justify-content-center">
    <table class="table">
        <thead class="thead-dark">
          <tr>
            <th class="text-center" scope="col">No.</th>
            <th class="text-center" scope="col">Reference No.</th>
            <th class="text-center" scope="col">Receiver</th>
            <th class="text-center" scope="col">Receiving Office</th>
            <th class="text-center" scope="col">Status</th>
            <th class="text-center" scope="col">Details</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"> <?php echo e($loop->iteration); ?> </td>
                    <td class="text-center"> <?php echo e($row->referenceNo); ?></td>
                    <td class="text-center"><?php echo e($row->receiverName); ?></td>
                    <td class="text-center"><?php echo e($row->officeName); ?></td>
                        <?php if($row->status == 3): ?>
                            <td class="d-flex text-center" style="justify-content: center;"><p>Sent Back</p>&nbsp;<button type="button" class="btn btn-danger"></button></td>
                        <?php endif; ?>
                        <?php if($row->status == 2): ?>
                            <td class="d-flex text-center" style="justify-content: center;"><p>Circulating</p>&nbsp;<button type="button" class="btn btn-info"></button></td>
                        <?php endif; ?>
                        <?php if($row->status == 1): ?>
                        <td class="d-flex text-center" style="justify-content: center;"><p>Completed</p>&nbsp;<button type="button" class="btn btn-success"></button></td>
                        <?php endif; ?>
                    <td class="text-center"><a href="http://127.0.0.1:8000/qrinfo/<?php echo e($row->referenceNo); ?>" title="Click for more Information">Info</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    <?php elseif(count($data) == 0): ?>
        <p class="display-4 text-center">No 'results' found</td></p>
    <?php else: ?>
        <p class="display-4">No 'results' found</td></p>
    <?php endif; ?>
</div>
<script>

</script>

  <script>
    // Add active class to the current button (highlight it)
    var header = document.getElementById("nav");
    var btns = header.getElementsByClassName("btn");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function() {
      var current = document.getElementsByClassName("active");
      current[0].className = current[0].className.replace(" active", "");
      this.className += " active";
      });
    }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\FROM E\cmudts\doctrasys\resources\views/users/searchByDate.blade.php ENDPATH**/ ?>