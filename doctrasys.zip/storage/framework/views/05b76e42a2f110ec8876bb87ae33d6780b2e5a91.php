<?php $__env->startSection('content'); ?>
<style>
    html, body {
      background-color:  #A0D6B4;
  }
  .chart-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  /* max-width: 800px; */
  margin: 0 auto;
}

.next-page-button {
  display: block;
  margin: 20px auto;
}
</style>

    <div class="container-fluid">
        <div class="row">
            <h4><strong>Documents Summary</strong></h4>
            <div class="col-md-12">
                <div class="my-3">
                    <div class="row justify-content-between">
                        <div class="col-md-3 m-auto p-3 levitating-div bg-white rounded">
                            <h2 class="font-weight-bolder mb-0">
                                <?php echo e($totalDocs); ?>

                            </h2>
                            <p class="text-sm mb-0 text-capitalize">Total</p>
                        </div>

                        <div class="col-md-3 m-auto p-3 levitating-div bg-white rounded">
                            <h2 class="font-weight-bolder mb-0">
                                <?php echo e($taggedDocs); ?>

                            </h2>
                            <p class="text-sm mb-0 text-capitalize">Approved</p>
                        </div>

                        <div class="col-md-3 m-auto p-3 levitating-div bg-white rounded">
                            <h3 class="font-weight-bolder mb-0">
                                <?php echo e($sentBack); ?>

                            </h3>
                            <p class="text-sm mb-0 text-capitalize">Rejected</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-between">
            <h4><strong>Document Count per Office</strong></h4>
            <?php $__currentLoopData = $eachOfficeCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachOffice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 m-4 p-2 levitating-div bg-white rounded">
                <h2 class="font-weight-bolder mb-0">
                    <?php echo e($eachOffice->total); ?>

                </h2>
                <p class="text-sm mb-0 text-capitalize"><?php echo e($eachOffice->officeName); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row justify-content-between">
            <h4><strong>Document Count per Document Type</strong></h4>
            <?php $__currentLoopData = $eachDocTypeCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 m-4 p-2 levitating-div bg-white rounded">
                <h2 class="font-weight-bolder mb-0">
                    <?php echo e($each->total); ?>

                </h2>
                <p class="text-sm mb-0 text-capitalize"><?php echo e($each->docType); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Balleza\Desktop\CMU-DOCTRASYS\cmudts\doctrasys\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>