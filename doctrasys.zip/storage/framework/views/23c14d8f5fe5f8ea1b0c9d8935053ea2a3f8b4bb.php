<?php $__env->startSection('content'); ?>
<style>
.container {
    position: relative;
        top: 120px;
        height: 100%;
}
</style>
<form action="send-back/<?php echo e($doc->referenceNo); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="container col-lg-10">
    <label for=""></label>
        <div class="mb-3">
            <input class="form-control "type="text" style="display: none;" name='status' value="3">
        </div>
    <button type="submit">Confirm</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\cmudts\doctrasys\resources\views/users/sendBack.blade.php ENDPATH**/ ?>